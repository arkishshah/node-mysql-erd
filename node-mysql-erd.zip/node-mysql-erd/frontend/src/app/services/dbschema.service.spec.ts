import { TestBed } from '@angular/core/testing';

import { DbschemaService } from './dbschema.service';

describe('DbschemaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DbschemaService = TestBed.get(DbschemaService);
    expect(service).toBeTruthy();
  });
});
