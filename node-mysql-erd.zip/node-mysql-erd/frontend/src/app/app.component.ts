import { DbschemaService } from './services/dbschema.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  dbSchemaRes: any;
  dbSchemaKeys: any;
  constructor(private dbschemaService: DbschemaService){}

  ngOnInit() {
    this.dbschemaService.getDbSchema().subscribe( (res) => {
      this.dbSchemaRes = res;
      this.dbSchemaKeys = Object.keys(res);
      console.log(this.dbSchemaKeys);
    })
  }
}
