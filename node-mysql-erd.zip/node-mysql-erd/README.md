# node-mysql-erd
Application to connect to the MySQL database and dynamically generate relationship diagrams.
