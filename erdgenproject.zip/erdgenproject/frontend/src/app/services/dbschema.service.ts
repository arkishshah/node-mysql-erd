import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DbschemaService {
  BASE_URL: string = 'http://localhost:3000/';
  constructor(private http: HttpClient) { }
  
  getDbSchema(){
    return this.http.get(this.BASE_URL+'getdbschema');
  }
}
