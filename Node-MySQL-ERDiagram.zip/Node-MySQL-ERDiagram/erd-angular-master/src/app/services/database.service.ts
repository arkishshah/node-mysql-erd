import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DatabaseService {
  private URL = environment.API_URL;
  private connectLine = new BehaviorSubject([]);
  private highlightObject = new BehaviorSubject([]);
  public selectedDatabase = '';
  constructor(
    private httpClient: HttpClient
    ) { }

    setLines(lines) {
      this.connectLine.next(lines);
    }

    getLines(): Observable<any> {
      return this.connectLine.asObservable();
    }

    sethighlightObject(lines) {
      this.highlightObject.next(lines);
    }
    gethighlightObject(): Observable<any> {
      return this.highlightObject.asObservable();
    }

    getDatabasesList() {
      return this.httpClient
                 .get(this.URL + '/api/databases');
    }

    getDatabaseSchema(dbName) {
      return this.httpClient
                 .get(this.URL + '/api/database/' + dbName);
    }

    getData(data) {
      return this.httpClient.post(this.URL + '/api/database/getData', data);
    }
}
