import { Component, OnInit, Inject } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';


@Component({
  selector: 'app-table-dialog-content',
  templateUrl: './table-dialog-content.component.html',
  styleUrls: ['./table-dialog-content.component.less']
})
export class TableDialogContentComponent implements OnInit {
  public table: any;

  constructor(
    private dialogRef: MatDialogRef<TableDialogContentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      if (data) {
        this.table = this.data;
      }
      if (!data) {
        this.table = undefined;
      }
    }

  ngOnInit() {
  }

  closeDialog() {
    this.dialogRef.close();
  }
}
