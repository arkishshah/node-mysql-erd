import { Component, OnInit } from '@angular/core';
import { DatabaseService } from './services/database.service';
import { MatDialog } from '@angular/material';
import { TableDialogContentComponent } from './table-dialog-content/table-dialog-content.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less'],
})
export class AppComponent implements OnInit {
  public databases = [];
  public selectedDB: any = {};

  lineArray = [];
  relations = [];

  public relatedTables = [];
  public normalTables = [];


  constructor(
    private databaseService: DatabaseService,
    private dialog: MatDialog
    ) { }
  ngOnInit() {
    this.databaseService.getDatabasesList().subscribe((response) => {
      this.databases = response['databases'];
    });
  }

  onDatabaseChange(event) {
    this.removelines();
    this.relatedTables = [];
    this.normalTables = [];
    this.lineArray = [];
    this.databaseService.getDatabaseSchema(event.value).subscribe((response) => {
      this.selectedDB = response['database'];
      this.databaseService.selectedDatabase = event.value;
      this.relations = response['database']['relations'];
      if (this.relations.length > 0) {
        let dbNames = [];
        this.relations.forEach(relation => {
          dbNames.push(relation.parent);
          dbNames.push(relation.child);
        });
        dbNames = Array.from(new Set(dbNames));
        this.selectedDB['tables'].forEach(table => {
          if (dbNames.findIndex(name => name === table.name) !== -1) {
            this.relatedTables.push(table);
          } else {
            this.normalTables.push(table);
          }
        });
        this.connectlines();
      } else {
        this.normalTables = this.selectedDB['tables'];
      }
    });
  }
  removelines() {
    this.lineArray = [];
    const removeElements = (elms) => elms.forEach(el => el.remove());
    removeElements( document.querySelectorAll('.line-css') );
  }
  connectlines() {
    this.databaseService.setLines([]);
    setTimeout(() => {
      if (this.relations && this.relations.length > 0) {
        this.relations.forEach((relation, index) => {
          const parentDiv = document.getElementById(relation['parent']);
          this.relations[index]['pline'] = this.getOffset(parentDiv);

          const childDiv = document.getElementById(relation['child']);
          this.relations[index]['cline'] = this.getOffset(childDiv);
        });
        this.relations.forEach(relation => {
          if (relation['child'] === relation['parent']) {
            this.connect(relation['cline'], relation['pline'], '#0000ff', 1, relation, true);
          } else {
            if (relation['pline'].left > relation['cline'].left) {
              this.connect(relation['cline'], relation['pline'], '#0000ff', 1, relation);
            } else {
              this.connect(relation['pline'], relation['cline'], '#0000ff', 1, relation);
            }
          }
        });
        this.databaseService.setLines(this.lineArray);
      }
    }, 500);
  }
  openDialog() {
    this.dialog.open(TableDialogContentComponent);
  }
  connect(table1, table2, color, thickness, relation, sameTable= false) {
    // bottom right
    const x1 = table1.left + table1.width;
    const y1 = (table1.top + (table1.height / 2));
    // top right
    const x2 = table2.left;
    const y2 = (table2.top + table2.height / 2);
    // distance
    let length = Math.sqrt(((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)));
    // center
    let cx = ((x1 + x2) / 2) - (length / 2);
    const cy = ((y1 + y2) / 2) - (thickness / 2);
    // angle
    let angle = Math.atan2((y1 - y2), (x1 - x2)) * (180 / Math.PI);
    const angleText =  angle * -1 ;

     // line creation
    let css = 'line-css';
    if (sameTable) {
      css = 'line-css half-circle';
      length = length / 2;
      color = '#ffffff';
      angle = 270;
      cx = cx - (length / 2 ) - 20;
      thickness = 40;
    }

    const line = {
      'css': css,
      'thickness': thickness,
      'color': color,
      'cx': cx,
      'cy': cy,
      'length': length,
      'angle': angle,
      'angleText': angleText,
      'table': relation,
      'lineStyle': {
        'padding': '0px',
        'margin': '0px',
        'height': thickness + 'px',
        'background-color': color,
        'line-height': '1px',
        'position': 'absolute',
        'left': cx + 'px',
        'top': cy + 'px',
        'width': length + 'px',
        '-moz-transform': 'rotate(' + angle + 'deg)',
        '-webkit-transform': 'rotate(' + angle + 'deg)',
        '-o-transform': 'rotate(' + angle + 'deg)',
        '-ms-transform': 'rotate(' + angle + 'deg)',
        'transform': 'rotate(' + angle + 'deg)',
      },
      'testStyle' : {
        '-moz-transform': 'rotate(' + angleText + 'deg)',
        '-webkit-transform': 'rotate(' + angleText + 'deg)',
        '-o-transform': 'rotate(' + angleText + 'deg)',
        '-ms-transform': 'rotate(' + angleText + ')',
        'transform': 'rotate(' + angleText + 'deg)'
      }
    };

    this.lineArray.push(line);
  }

  getOffset(el) {
    const rect = el.getBoundingClientRect();
    return {
      left: rect.left + window.pageXOffset,
      top: rect.top + window.pageYOffset,
      width: rect.width || el.offsetWidth,
      height: rect.height || el.offsetHeight
    };
  }
   onResizeLine() {
    this.removelines();
    this.connectlines();
   }
}
