import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef, MatTableDataSource, MatPaginator} from '@angular/material';


@Component({
  selector: 'app-table-data',
  templateUrl: './table-data.component.html',
  styleUrls: ['./table-data.component.less']
})
export class TableDataComponent implements OnInit {
  public tableData: any;
  public columnNames = [];
  dataSource: any;
  displayedColumns = [];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(
    private dialogRef: MatDialogRef<TableDataComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      if (data) {
        this.tableData = this.data;
        console.log(this.tableData, 'tabledata');
        if (this.tableData['data'] && this.tableData['data'].length > 0) {
        
          this.dataSource = new MatTableDataSource(this.tableData['data']);

          this.columnNames = Object.keys(this.tableData['data'][0]);
          this.displayedColumns = Object.keys(this.tableData['data'][0]);
        }
      }
      if (!data) {
        this.tableData = {};
      }
    }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
  }

  closeDialog() {
    this.dialogRef.close();
  }
}
