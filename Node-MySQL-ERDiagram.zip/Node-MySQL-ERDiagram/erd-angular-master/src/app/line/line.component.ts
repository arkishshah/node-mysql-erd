import { Component, OnInit, Output, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { DatabaseService } from '../services/database.service';
import { MatDialog } from '@angular/material';
import { TableDataComponent } from '../table-data/table-data.component';

@Component({
  selector: 'app-line',
  templateUrl: './line.component.html',
  styleUrls: ['./line.component.less']
})
export class LineComponent implements OnInit, OnDestroy {
  subscription: Subscription;

  constructor(
    private dataBaseService: DatabaseService,
    private dialog: MatDialog
  ) { }
  public lines = [];
  public selectedIndex = -1;
  ngOnInit() {
    this.subscription = this.dataBaseService.getLines().subscribe(lines => {
      this.lines = lines;
    });

  }
  onMouseOver(relation, index) {
    this.selectedIndex = index;
    relation['hover'] = true;
    this.dataBaseService.sethighlightObject(relation);
  }
  onMouseLeave(relation, index) {
    setTimeout(() => {
      this.selectedIndex = -1;
      relation['hover'] = false;
      this.dataBaseService.sethighlightObject(relation);
    }, 500);
  }

  showData(relation) {
    const dbDetails = {
      dbName: this.dataBaseService.selectedDatabase,
      parent: relation['parent'],
      child: relation['child'],
      parentField: relation['parentField'],
      childField: relation['childField']
    };
    this.dataBaseService.getData(dbDetails).subscribe(data => {
      console.log(data, 'data');
      const tableData = {};
      tableData['name'] = relation['parent'];
      tableData['data'] = data['tableData'];
      this.dialog.open(TableDataComponent, {data: tableData, panelClass:'table-details' });
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
