import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import {MatDialog} from '@angular/material';
import {TableDialogContentComponent} from '../table-dialog-content/table-dialog-content.component';
import { Subscription } from 'rxjs';
import { DatabaseService } from '../services/database.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.less']
})
export class TableComponent implements OnInit, OnDestroy {
  @Input() table: any;
  constructor(private dialog: MatDialog, private dataBaseService: DatabaseService) { }
  subscription: Subscription;
  public highLightTables = [];
  public highLightObject = {};
  openDialog(table: any) {
    this.dialog.open(TableDialogContentComponent, {data: table });
  }

  ngOnInit() {
    this.subscription = this.dataBaseService.gethighlightObject().subscribe(relation => {
      if (relation['hover']) {
        this.highLightTables.push(relation['child']);
        this.highLightTables.push(relation['parent']);
        this.highLightObject = relation;

      } else {
        this.highLightTables = [];
        this.highLightObject = {};
      }

    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
