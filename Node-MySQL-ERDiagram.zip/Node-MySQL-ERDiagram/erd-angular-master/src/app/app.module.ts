import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {
  MatIconModule,
  MatInputModule,
  MatFormFieldModule,
  MatSelectModule,
  MatDialogModule,
  MatButtonModule,
  MatTableModule,
  MatPaginatorModule
 } from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { DatabaseService } from './services/database.service';
import { TableComponent } from './table/table.component';
import { TableDialogContentComponent } from './table-dialog-content/table-dialog-content.component';
import { LineComponent } from './line/line.component';
import { TableDataComponent } from './table-data/table-data.component';

@NgModule({
  declarations: [
    AppComponent,
    TableComponent,
    TableDialogContentComponent,
    LineComponent,
    TableDataComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatPaginatorModule
  ],
  providers: [
    DatabaseService,
    TableDialogContentComponent
  ],
  exports: [
    MatDialogModule,
    MatIconModule
  ],
  bootstrap: [AppComponent],
  entryComponents: [TableDialogContentComponent, TableDataComponent]
})
export class AppModule { }
