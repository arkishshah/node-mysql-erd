const db = require('../dbConnection/connection'); //reference of connection
 
const DatabaseModel = {

  getAllDB: function(callback) {
    const sql = `SHOW DATABASES`;
    return db.query(sql, callback);
  },

  getAllTables: function(dbname,callback) {
    const sql = `SHOW TABLES FROM ${dbname}`;
    return db.query(sql, callback);
  },

  getTableDetails: function(tableName, callback) {
    // const sql = `select * from ${tableName}`;
    const sql = `explain ${tableName}`;
    return db.query(sql, callback);
  },

  getTableRelation: function(dbname, callback) {
    const sql = `SELECT TABLE_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE CONSTRAINT_SCHEMA = '${dbname}' AND REFERENCED_TABLE_SCHEMA IS NOT NULL AND REFERENCED_TABLE_NAME IS NOT NULL AND REFERENCED_COLUMN_NAME IS NOT NULL`;
    return db.query(sql, callback);
  },
  
  getTableData: function(dbDetails, callback) {
    if (dbDetails.dbName) {
      const sql = `USE ${dbDetails.dbName}`;
      db.query(sql);
      const parentField = dbDetails['parent'] + '.' + dbDetails['parentField'];
      const childField = dbDetails['child'] + '.' + dbDetails['childField'];
      const infoSql = `SELECT * FROM ${dbDetails['parent']} JOIN ${dbDetails['child']} ON ${parentField} = ${childField}`;
      return db.query(infoSql, callback);
    } else {
      return callback(null);
    }
  }

  
}

module.exports = DatabaseModel;