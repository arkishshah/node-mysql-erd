const DatabaseModel = require('../models/database');

// node won't wait functional execution, it will execute like line by line in a single thread
const async = require("async"); 

/**
 * return the database list 
 */
exports.getDatabases = function (req, res) {

  DatabaseModel.getAllDB(function (err, database) {
    if (err) {
      return res.json({ error : err });
    }
    const dbNames = [];
    const defaultDB = [ 'information_schema', 'mysql', 'performance_schema', 'sys', 'phpmyadmin' ];
    for (const dbName of database) {
      // Avoiding default system databases
      if (defaultDB.indexOf(dbName.Database) === -1) {
        dbNames.push(dbName.Database);
      }
    }
    return res.json({ databases: dbNames });
  });
};

/**
 * return list of tables base on DB
 */
exports.getTables = function (req, res) {
  const dbName = req.params.name;
  const details = {
    database: {
      name: dbName,
      tables: [],
      relations : []
    }
  }

  async.series([
    (callback) => {
      // return between table relation based on database name
      DatabaseModel.getTableRelation(dbName, function (err, relation) {
        if (err) {
          console.log(err, 'err');
        }

        for (const r of relation) {
          const relationship = {
            child : r['TABLE_NAME'],
            parent : r['REFERENCED_TABLE_NAME'],
            parentField : r['REFERENCED_COLUMN_NAME'],
            childField: r['COLUMN_NAME']
          };
          details['database']['relations'].push(relationship);
        }
        // console.log(relation, 'relationship---->');
        callback(null);
      });
    }
  ], (err, result) => {
      if (err) {
        throw err;
      }
    // return table list based on database name
    DatabaseModel.getAllTables(dbName,function (err, tables) {
      if (err) {
        return res.json({ error : err });
      }

      async.map(tables, function (table, callback) {
        const tableName = dbName + '.' + table['Tables_in_' + dbName];
        const tableDetail = {
          name: table['Tables_in_' + dbName],
          fields: []
        };

        // get table details like 'field, type, key, default' based on table name
        DatabaseModel.getTableDetails(tableName, function (err, detail) {
          if (err) {
            // callback(err);
            console.log('err', err);
          }
          tableDetail['fields'] = detail;
          callback(null, tableDetail);
        });
      }, function (err, tablesdetail) {
          if (err) {
            return res.json({ error : err });
          }
          details['database']['tables'] = tablesdetail;
          details['database']['relations'].forEach((relation, i) => {
            const index = tablesdetail.findIndex(table => table.name === relation.child);
            const relationField = tablesdetail[index]['fields'].find(field => field.Field === relation.childField)
            const priCheck = tablesdetail[index]['fields'].filter(field => field.Key === 'PRI');
            if (relation.parent === relation.child || relationField['Key'] === 'UNI' || (priCheck.length === 1 && priCheck[0]['Field'] === relationField['Field'])) {
              details['database']['relations'][i]['type'] = "1-1";
            } else {
              details['database']['relations'][i]['type'] = "1-N";
            }

          });
          return res.json(details);
      });
    });
  })

};


/**
 * return the data from the table
 */
exports.getData = function (req, res) {
  const dbDetails = JSON.parse(JSON.stringify(req.body));
  DatabaseModel.getTableData(dbDetails, function (err, tableData) {
    if (err) {
      return res.json({ error : err });
    }
    return res.json({ tableData: tableData });
  });
};