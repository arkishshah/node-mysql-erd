const express = require('express');
const router = express.Router();
const DatabaseController = require('../controllers/database');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

/**
 * GET databases list
 */
router.get('/api/databases', DatabaseController.getDatabases);

/**
 * GET tables list base on database name
 */
router.get('/api/database/:name', DatabaseController.getTables);


/**
 * GET data from table
 */

router.post('/api/database/getData', DatabaseController.getData);


module.exports = router;
